package tecebook;

import java.util.Scanner;

// TODO: Auto-generated Javadoc
/**
 * The Class ProfileView.
 *
 * @author a19guillermong
 */
public class ProfileView {

    /** The posts showed. */
    private int postsShowed = 10;
    
    /** The profile controller. */
    private ProfileController profileController;

    /**
     * Gets the posts showed.
     *
     * @return the posts showed
     */
    public int getPostsShowed() {
        return postsShowed;
    }

    /**
     * Sets the posts showed.
     *
     * @param postsShowed the new posts showed
     */
    public void setPostsShowed(int postsShowed) {
        this.postsShowed = postsShowed;
    }

    /**
     * Instantiates a new profile view.
     *
     * @param profileController the profile controller
     */
    public ProfileView(ProfileController profileController) {
        this.profileController=profileController;
    }

    /**
     * Show profile info.
     *
     * @param ownProfile the own profile
     * @param profile the profile
     */
    private void showProfileInfo(boolean ownProfile, Profile profile) {
        System.out.println("Nombre: " + profile.getName());
        System.out.println("Status: " + profile.getStatus());

    }

    /**
     * Change status.
     *
     * @param ownProfile the own profile
     * @param scanner the scanner
     * @param profile the profile
     */
    private void changeStatus(boolean ownProfile, Scanner scanner, Profile profile) {
        scanner.nextLine();
            if (ownProfile) {
            System.out.println("Introduce un nuevo estado:");
            String status = scanner.nextLine();
            profile.setStatus(status);
            profileController.updateProfileStatus(status);
        } else {
            System.out.println("Esta opcion solo es valida en la propia biografía \n");
            showProfileMenu(profile);
        }
    }

    /**
     * Show profile menu.
     *
     * @param profile the profile
     */
    public void showProfileMenu(Profile profile) {
        showProfileInfo(true, profile);
        System.out.println("1. Cambiar el estado");
        System.out.println("2. Cerrar Sesión");
        Scanner scanner = new Scanner (System.in);
        int option = scanner.nextInt();
        
       switch(option){
           case 1:
                changeStatus(true, scanner, profile);
                break;
           case 2: 
               break;
           default: 
               System.out.println("Opción erronea");
               showProfileMenu(profile);
       
       }
    }

}
