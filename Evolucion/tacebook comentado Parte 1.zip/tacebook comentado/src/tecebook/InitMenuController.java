package tecebook;

// TODO: Auto-generated Javadoc
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 * The Class InitMenuController.
 *
 * @author a19carlosvz
 */
public class InitMenuController {

    /** The init menu view. */
    private InitMenuView initMenuView = new InitMenuView(this);

    /**
     * The main method.
     *
     * @param args the arguments
     */
    public static void main(String[] args) {
        InitMenuController object = new InitMenuController();
        object.init();

    }

    /**
     * Inits the.
     */
    private void init() {
        while (!initMenuView.showLoginMenu());
    }

    /**
     * Permite al usuario hacer loggin.
     *
     * @param username the username
     * @param password the password
     */
    public void login(String username, String password) {
        Profile p = ProfileDB.findByNameAndPassword(username, password, 0);

        if (p == null) {
            this.initMenuView.showLoginErrorMessage();
        } else {
            ProfileController loginProfile = new ProfileController();
            loginProfile.openSession(p);
        }
        
    }

    /**
     * Register.
     */
    public void register() {
        this.initMenuView.showRegisterMenu();
    }

    /**
     * Creates the profile.
     *
     * @param name the name
     * @param password the password
     * @param status the status
     */
    public void createProfile(String name, String password, String status) {

        while (ProfileDB.findByName(name, 0) != null) {
            name = this.initMenuView.showNewNameMenu();
        }
        Profile profile = new Profile(name, password, status);
        ProfileDB.save(profile);
        ProfileController newProfile = new ProfileController();
        newProfile.openSession(profile);
    }
    
}
