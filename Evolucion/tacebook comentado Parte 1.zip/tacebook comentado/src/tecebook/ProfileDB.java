package tecebook;

// TODO: Auto-generated Javadoc
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * The Class ProfileDB.
 *
 * @author a19carlosvz
 */
public class ProfileDB {

    /**
     * Find by name.
     *
     * @param name the name
     * @param numberOfPosts the number of posts
     * @return the profile
     */
    //no se que hacer con el numberOfPosts
    public static Profile findByName(String name, int numberOfPosts) {
        for (int i = 0; i < TacebookDB.getProfiles().size(); i++) {
            if (name.equals(TacebookDB.getProfiles().get(i).getName())) {
                return TacebookDB.getProfiles().get(i);
            }
        }
        return null;
    }

    /**
     * Find by name and password.
     *
     * @param name the name
     * @param password the password
     * @param numberOfPosts the number of posts
     * @return the profile
     */
    public static Profile findByNameAndPassword(String name, String password, int numberOfPosts) {
        for (int i = 0; i < TacebookDB.getProfiles().size(); i++) {
            if (TacebookDB.getProfiles().get(i).getName().equals(name) &&
                    TacebookDB.getProfiles().get(i).getPassword().equals(password)) {
                return TacebookDB.getProfiles().get(i);
            } else {
            }
        }
        return null;
    }

    /**
     * Save.
     *
     * @param profile the profile
     */
    public static void save(Profile profile) {
        TacebookDB.getProfiles().add(profile);
    }

    /**
     * Update.
     *
     * @param profile the profile
     */
    public static void update(Profile profile) {
    }
    
    /**
     * Save friendship request.
     *
     * @param destProfile the dest profile
     * @param sourceProfile the source profile
     */
    public static void saveFriendshipRequest(Profile destProfile, Profile sourceProfile){
         
         }

}
