package tecebook;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


import java.util.ArrayList;

// TODO: Auto-generated Javadoc
/**
 * The Class TacebookDB.
 *
 * @author a19carlosvz
 */
public class TacebookDB {
    
    /** The profiles. */
    private static ArrayList <Profile> profiles = new ArrayList<Profile>();

    /**
     * Gets the profiles.
     *
     * @return the profiles
     */
    public static ArrayList<Profile> getProfiles() {
        return profiles;
    }
    
    
}
