package tecebook;


// TODO: Auto-generated Javadoc
/**
 * The Class ProfileController.
 *
 * @author a19guillermong
 */
public class ProfileController {
    
    /** The profile view. */
    private ProfileView profileView = new ProfileView(this);
    
    /** The session profile. */
    private Profile sessionProfile;

    /**
     * Gets the session profile.
     *
     * @return the session profile
     */
    public Profile getSessionProfile() {
        return sessionProfile;
    }

    /**
     * Sets the session profile.
     *
     * @param sessionProfile the new session profile
     */
    public void setSessionProfile(Profile sessionProfile) {
        this.sessionProfile = sessionProfile;
    }   

	
	/**
	 * Gets the posts showed.
	 *
	 * @return the posts showed
	 */
	public int getPostsShowed() {
		int posts= this.profileView.getPostsShowed();
		return posts;
	}
        
        /**
         * Reload profile.
         */
        public void reloadProfile(){
            
         this.sessionProfile = ProfileDB.findByName(sessionProfile.getName(), profileView.getPostsShowed());
         profileView.showProfileMenu(sessionProfile);
        }
        
        /**
         * Open session.
         *
         * @param sessionProfile the session profile
         */
        public void openSession(Profile sessionProfile){
            this.sessionProfile = sessionProfile;
            this.profileView.showProfileMenu(sessionProfile);
            
        }
        
        /**
         * Update profile status.
         *
         * @param newStatus the new status
         */
        public void updateProfileStatus(String newStatus){
            sessionProfile.setStatus(newStatus);
            ProfileDB.save(sessionProfile);
            reloadProfile();
            
            
        }
}
