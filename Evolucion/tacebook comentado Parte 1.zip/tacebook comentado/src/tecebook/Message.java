package tecebook;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


import java.util.Date;

// TODO: Auto-generated Javadoc
/**
 * The Class Message.
 *
 * @author a19carlosvz
 */
public class Message {
    
    /** The id. */
    private int id;
    
    /** The text. */
    private String text;
    
    /** The date. */
    private Date date;
    
    /** The read. */
    private boolean read;

    /**
     * Instantiates a new message.
     *
     * @param id the id
     * @param text the text
     * @param date the date
     * @param read the read
     */
    public Message(int id, String text, Date date, boolean read) {
        this.id = id;
        this.text = text;
        this.date = date;
        this.read = read;
    }

    /**
     * Gets the id.
     *
     * @return the id
     */
    public int getId() {
        return id;
    }

    /**
     * Sets the id.
     *
     * @param id the new id
     */
    public void setId(int id) {
        this.id = id;
    }

    /**
     * Gets the text.
     *
     * @return the text
     */
    public String getText() {
        return text;
    }

    /**
     * Sets the text.
     *
     * @param text the new text
     */
    public void setText(String text) {
        this.text = text;
    }

    /**
     * Gets the date.
     *
     * @return the date
     */
    public Date getDate() {
        return date;
    }

    /**
     * Sets the date.
     *
     * @param date the new date
     */
    public void setDate(Date date) {
        this.date = date;
    }

    /**
     * Checks if is read.
     *
     * @return true, if is read
     */
    public boolean isRead() {
        return read;
    }

    /**
     * Sets the read.
     *
     * @param read the new read
     */
    public void setRead(boolean read) {
        this.read = read;
    }
    
}
