package tecebook;


/**
 * @author a19guillermong
 *
 */
public class ProfileController {
    
    private ProfileView profileView = new ProfileView(this);
    
    private Profile sessionProfile;

    public Profile getSessionProfile() {
        return sessionProfile;
    }

    public void setSessionProfile(Profile sessionProfile) {
        this.sessionProfile = sessionProfile;
    }   

	
	public int getPostsShowed() {
		int posts= this.profileView.getPostsShowed();
		return posts;
	}
        public void reloadProfile(){
            
         this.sessionProfile = ProfileDB.findByName(sessionProfile.getName(), profileView.getPostsShowed());
         profileView.showProfileMenu(sessionProfile);
        }
        
        public void openSession(Profile sessionProfile){
            this.sessionProfile = sessionProfile;
            this.profileView.showProfileMenu(sessionProfile);
            
        }
        
        public void updateProfileStatus(String newStatus){
            sessionProfile.setStatus(newStatus);
            ProfileDB.save(sessionProfile);
            reloadProfile();
            
            
        }
}
