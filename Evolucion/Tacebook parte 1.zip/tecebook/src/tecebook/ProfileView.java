package tecebook;

import java.util.Scanner;

/**
 * @author a19guillermong
 *
 */
public class ProfileView {

    private int postsShowed = 10;
    private ProfileController profileController;

    public int getPostsShowed() {
        return postsShowed;
    }

    public void setPostsShowed(int postsShowed) {
        this.postsShowed = postsShowed;
    }

    public ProfileView(ProfileController profileController) {
        this.profileController=profileController;
    }

    private void showProfileInfo(boolean ownProfile, Profile profile) {
        System.out.println("Nombre: " + profile.getName());
        System.out.println("Status: " + profile.getStatus());

    }

    private void changeStatus(boolean ownProfile, Scanner scanner, Profile profile) {
        scanner.nextLine();
            if (ownProfile) {
            System.out.println("Introduce un nuevo estado:");
            String status = scanner.nextLine();
            profile.setStatus(status);
            profileController.updateProfileStatus(status);
        } else {
            System.out.println("Esta opcion solo es valida en la propia biografía \n");
            showProfileMenu(profile);
        }
    }

    public void showProfileMenu(Profile profile) {
        showProfileInfo(true, profile);
        System.out.println("1. Cambiar el estado");
        System.out.println("2. Cerrar Sesión");
        Scanner scanner = new Scanner (System.in);
        int option = scanner.nextInt();
        
       switch(option){
           case 1:
                changeStatus(true, scanner, profile);
                break;
           case 2: 
               break;
           default: 
               System.out.println("Opción erronea");
               showProfileMenu(profile);
       
       }
    }

}
