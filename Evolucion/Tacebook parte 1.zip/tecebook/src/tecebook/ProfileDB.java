package tecebook;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author a19carlosvz
 */
public class ProfileDB {

    //no se que hacer con el numberOfPosts
    public static Profile findByName(String name, int numberOfPosts) {
        for (int i = 0; i < TacebookDB.getProfiles().size(); i++) {
            if (name.equals(TacebookDB.getProfiles().get(i).getName())) {
                return TacebookDB.getProfiles().get(i);
            }
        }
        return null;
    }

    public static Profile findByNameAndPassword(String name, String password, int numberOfPosts) {
        for (int i = 0; i < TacebookDB.getProfiles().size(); i++) {
            if (TacebookDB.getProfiles().get(i).getName().equals(name) &&
                    TacebookDB.getProfiles().get(i).getPassword().equals(password)) {
                return TacebookDB.getProfiles().get(i);
            } else {
            }
        }
        return null;
    }

    public static void save(Profile profile) {
        TacebookDB.getProfiles().add(profile);
    }

    public static void update(Profile profile) {
    }

}
